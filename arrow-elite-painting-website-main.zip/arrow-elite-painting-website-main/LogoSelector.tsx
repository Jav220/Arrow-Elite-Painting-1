import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useState } from "react";

interface LogoSelectorProps {
  onLogoSelect: (logoType: string) => void;
}

export default function LogoSelector({ onLogoSelect }: LogoSelectorProps) {
  const [selectedLogo, setSelectedLogo] = useState<string>("");

  const handleSelect = (logoType: string) => {
    setSelectedLogo(logoType);
    onLogoSelect(logoType);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <h2 className="text-3xl font-bold text-center mb-8 text-gray-900">
            Choose Your Preferred Logo Design
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {/* Horizontal Logo */}
            <Card className={`cursor-pointer transition-all ${selectedLogo === 'horizontal' ? 'ring-2 ring-blue-600 bg-blue-50' : ''}`}>
              <CardHeader className="text-center">
                <div className="bg-white p-4 rounded border">
                  <svg width="300" height="90" viewBox="0 0 400 120" className="mx-auto">
                    <defs>
                      <linearGradient id="arrowGradient1" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#1e40af" />
                        <stop offset="100%" stopColor="#3b82f6" />
                      </linearGradient>
                    </defs>
                    <g>
                      <rect x="10" y="35" width="45" height="8" fill="url(#arrowGradient1)" rx="4"/>
                      <polygon points="55,25 80,40 55,55" fill="url(#arrowGradient1)"/>
                      <rect x="5" y="32" width="8" height="14" fill="#f59e0b" rx="2"/>
                      <rect x="3" y="30" width="12" height="4" fill="#dc2626" rx="2"/>
                    </g>
                    <text x="100" y="45" fontFamily="Arial, sans-serif" fontSize="24" fontWeight="bold" fill="#1e40af">ARROW</text>
                    <text x="100" y="65" fontFamily="Arial, sans-serif" fontSize="20" fontWeight="600" fill="#1e40af">ELITE PAINTING</text>
                    <text x="100" y="85" fontFamily="Arial, sans-serif" fontSize="10" fill="#6b7280">PROFESSIONAL PAINTING SERVICES</text>
                  </svg>
                </div>
                <CardTitle className="text-lg">Horizontal Logo</CardTitle>
                <p className="text-sm text-gray-600">Best for headers and main branding</p>
              </CardHeader>
              <CardContent>
                <Button 
                  onClick={() => handleSelect('horizontal')}
                  className={`w-full ${selectedLogo === 'horizontal' ? 'bg-blue-600' : 'bg-gray-600'}`}
                >
                  {selectedLogo === 'horizontal' ? 'Selected ✓' : 'Select This Logo'}
                </Button>
              </CardContent>
            </Card>

            {/* Compact Logo */}
            <Card className={`cursor-pointer transition-all ${selectedLogo === 'compact' ? 'ring-2 ring-blue-600 bg-blue-50' : ''}`}>
              <CardHeader className="text-center">
                <div className="bg-white p-4 rounded border">
                  <svg width="240" height="80" viewBox="0 0 300 100" className="mx-auto">
                    <defs>
                      <linearGradient id="arrowGradient2" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#1e40af" />
                        <stop offset="100%" stopColor="#3b82f6" />
                      </linearGradient>
                    </defs>
                    <g>
                      <rect x="5" y="28" width="36" height="6" fill="url(#arrowGradient2)" rx="3"/>
                      <polygon points="41,20 60,32 41,44" fill="url(#arrowGradient2)"/>
                      <rect x="2" y="26" width="6" height="11" fill="#f59e0b" rx="2"/>
                      <rect x="1" y="24" width="9" height="3" fill="#dc2626" rx="1"/>
                    </g>
                    <text x="80" y="36" fontFamily="Arial, sans-serif" fontSize="19" fontWeight="bold" fill="#1e40af">ARROW</text>
                    <text x="80" y="52" fontFamily="Arial, sans-serif" fontSize="16" fontWeight="600" fill="#1e40af">ELITE PAINTING</text>
                  </svg>
                </div>
                <CardTitle className="text-lg">Compact Version</CardTitle>
                <p className="text-sm text-gray-600">Perfect for smaller spaces</p>
              </CardHeader>
              <CardContent>
                <Button 
                  onClick={() => handleSelect('compact')}
                  className={`w-full ${selectedLogo === 'compact' ? 'bg-blue-600' : 'bg-gray-600'}`}
                >
                  {selectedLogo === 'compact' ? 'Selected ✓' : 'Select This Logo'}
                </Button>
              </CardContent>
            </Card>

            {/* Icon Only */}
            <Card className={`cursor-pointer transition-all ${selectedLogo === 'icon' ? 'ring-2 ring-blue-600 bg-blue-50' : ''}`}>
              <CardHeader className="text-center">
                <div className="bg-white p-4 rounded border">
                  <svg width="80" height="80" viewBox="0 0 100 100" className="mx-auto">
                    <defs>
                      <linearGradient id="arrowGradient3" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#1e40af" />
                        <stop offset="100%" stopColor="#3b82f6" />
                      </linearGradient>
                    </defs>
                    <g>
                      <rect x="19" y="41" width="41" height="7" fill="url(#arrowGradient3)" rx="3"/>
                      <polygon points="60,30 80,44 60,58" fill="url(#arrowGradient3)"/>
                      <rect x="14" y="38" width="7" height="13" fill="#f59e0b" rx="2"/>
                      <rect x="12" y="36" width="11" height="4" fill="#dc2626" rx="2"/>
                    </g>
                  </svg>
                </div>
                <CardTitle className="text-lg">Icon Only</CardTitle>
                <p className="text-sm text-gray-600">Great for favicons</p>
              </CardHeader>
              <CardContent>
                <Button 
                  onClick={() => handleSelect('icon')}
                  className={`w-full ${selectedLogo === 'icon' ? 'bg-blue-600' : 'bg-gray-600'}`}
                >
                  {selectedLogo === 'icon' ? 'Selected ✓' : 'Select This Logo'}
                </Button>
              </CardContent>
            </Card>

            {/* Vertical Logo */}
            <Card className={`cursor-pointer transition-all ${selectedLogo === 'vertical' ? 'ring-2 ring-blue-600 bg-blue-50' : ''}`}>
              <CardHeader className="text-center">
                <div className="bg-white p-4 rounded border">
                  <svg width="180" height="140" viewBox="0 0 220 180" className="mx-auto">
                    <defs>
                      <linearGradient id="arrowGradient4" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#1e40af" />
                        <stop offset="100%" stopColor="#3b82f6" />
                      </linearGradient>
                    </defs>
                    <g>
                      <rect x="75" y="28" width="32" height="6" fill="url(#arrowGradient4)" rx="3"/>
                      <polygon points="107,20 125,31 107,42" fill="url(#arrowGradient4)"/>
                      <rect x="72" y="26" width="5" height="10" fill="#f59e0b" rx="1"/>
                      <rect x="70" y="24" width="8" height="3" fill="#dc2626" rx="1"/>
                    </g>
                    <text x="30" y="80" fontFamily="Arial, sans-serif" fontSize="19" fontWeight="bold" fill="#1e40af">ARROW</text>
                    <text x="35" y="100" fontFamily="Arial, sans-serif" fontSize="16" fontWeight="600" fill="#1e40af">ELITE</text>
                    <text x="30" y="118" fontFamily="Arial, sans-serif" fontSize="16" fontWeight="600" fill="#1e40af">PAINTING</text>
                    <text x="35" y="135" fontFamily="Arial, sans-serif" fontSize="9" fill="#6b7280">PROFESSIONAL</text>
                    <text x="42" y="147" fontFamily="Arial, sans-serif" fontSize="9" fill="#6b7280">SERVICES</text>
                  </svg>
                </div>
                <CardTitle className="text-lg">Vertical Layout</CardTitle>
                <p className="text-sm text-gray-600">Ideal for business cards</p>
              </CardHeader>
              <CardContent>
                <Button 
                  onClick={() => handleSelect('vertical')}
                  className={`w-full ${selectedLogo === 'vertical' ? 'bg-blue-600' : 'bg-gray-600'}`}
                >
                  {selectedLogo === 'vertical' ? 'Selected ✓' : 'Select This Logo'}
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <Button 
              onClick={() => onLogoSelect(selectedLogo)}
              disabled={!selectedLogo}
              className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 text-lg"
            >
              Apply Selected Logo to Website
            </Button>
          </div>

          <div className="mt-8 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-semibold text-gray-900 mb-2">Logo Usage Guidelines:</h3>
            <ul className="text-sm text-gray-600 space-y-1">
              <li><strong>Horizontal:</strong> Best for headers, main branding, and wide spaces</li>
              <li><strong>Compact:</strong> Perfect for mobile navigation and smaller areas</li>
              <li><strong>Icon Only:</strong> Use for favicons, app icons, and tight spaces</li>
              <li><strong>Vertical:</strong> Great for business cards and tall layouts</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}