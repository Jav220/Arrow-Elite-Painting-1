import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Phone, Star, CheckCircle, Clock, Shield, ArrowRight, Palette } from "lucide-react";
import { Link } from "react-router-dom";

interface ServicePageLayoutProps {
  title: string;
  metaDescription: string;
  heroTitle: string;
  heroDescription: string;
  heroImage: string;
  services: string[];
  process: { title: string; description: string }[];
  benefits: string[];
  pricing?: { title: string; price: string; features: string[] }[];
  beforeAfter?: { before: string; after: string; title: string }[];
  gradientFrom: string;
  gradientTo: string;
  accentColor: string;
}

export default function ServicePageLayout({
  title,
  metaDescription,
  heroTitle,
  heroDescription,
  heroImage,
  services,
  process,
  benefits,
  pricing,
  beforeAfter,
  gradientFrom,
  gradientTo,
  accentColor
}: ServicePageLayoutProps) {
  // Update document title and meta description
  React.useEffect(() => {
    document.title = title;
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute('content', metaDescription);
    }
  }, [title, metaDescription]);

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <Link to="/" className="flex items-center">
              <img 
                src="/assets/gallery/logo-original.png" 
                alt="Arrow Elite Painting Logo" 
                className="h-12 w-auto mr-3"
                onError={(e) => {
                  e.currentTarget.src = "/assets/logo.png";
                }}
              />
              <div className={`text-2xl font-bold bg-gradient-to-r ${gradientFrom} ${gradientTo} bg-clip-text text-transparent`}>
                Arrow Elite Painting
              </div>
            </Link>
            
            <nav className="hidden lg:flex items-center space-x-8">
              <Link to="/#services" className={`text-gray-700 hover:text-${accentColor} font-medium transition-colors`}>Services</Link>
              <Link to="/#process" className={`text-gray-700 hover:text-${accentColor} font-medium transition-colors`}>Our Process</Link>
              <Link to="/#about" className={`text-gray-700 hover:text-${accentColor} font-medium transition-colors`}>About</Link>
              <Link to="/#locations" className={`text-gray-700 hover:text-${accentColor} font-medium transition-colors`}>Service Areas</Link>
              <div className="flex items-center space-x-4">
                <a href="tel:9188103453" className={`flex items-center text-${accentColor} font-semibold hover:opacity-80 transition-opacity`}>
                  <Phone className="w-4 h-4 mr-2" />
                  (918) 810-3453
                </a>
                <Button className={`bg-gradient-to-r ${gradientFrom} ${gradientTo} hover:opacity-90 text-white shadow-lg transform hover:scale-105 transition-all duration-200`}>
                  GET FREE ESTIMATE
                </Button>
              </div>
            </nav>
            
            {/* Mobile menu */}
            <div className="lg:hidden flex items-center space-x-4">
              <a href="tel:9188103453" className={`text-${accentColor}`}>
                <Phone className="w-6 h-6" />
              </a>
              <Button size="sm" className={`bg-gradient-to-r ${gradientFrom} ${gradientTo} hover:opacity-90`}>
                Free Estimate
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className={`relative bg-gradient-to-br ${gradientFrom} ${gradientTo} py-20`}>
        <div className="absolute inset-0 bg-white/10 backdrop-blur-sm"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className={`mb-4 bg-white/20 text-white border-white/30 shadow-lg`}>
                <Palette className="w-4 h-4 mr-2" />
                Professional Service
              </Badge>
              <h1 className="text-5xl font-bold text-white mb-6 drop-shadow-lg">
                {heroTitle}
              </h1>
              <p className="text-xl text-white/90 mb-8 drop-shadow">
                {heroDescription}
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-white text-gray-900 hover:bg-gray-100 shadow-xl transform hover:scale-105 transition-all duration-200">
                  <Phone className="w-5 h-5 mr-2" />
                  Call (918) 810-3453
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-gray-900 shadow-xl">
                  Get Free Estimate
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-pink-400 to-purple-500 rounded-lg transform rotate-3 opacity-20"></div>
              <img 
                src={heroImage}
                alt={heroTitle}
                className="relative rounded-lg shadow-2xl transform hover:scale-105 transition-transform duration-300"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Offered */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className={`text-4xl font-bold bg-gradient-to-r ${gradientFrom} ${gradientTo} bg-clip-text text-transparent mb-4`}>
              Our {heroTitle} Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional, reliable, and beautiful results every time.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border-0 shadow-lg">
                <CardHeader className={`bg-gradient-to-br ${gradientFrom} ${gradientTo} text-white`}>
                  <CardTitle className="flex items-center">
                    <CheckCircle className="w-5 h-5 mr-2" />
                    {service}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <Button className={`w-full bg-gradient-to-r ${gradientFrom} ${gradientTo} hover:opacity-90 shadow-lg`}>
                    Learn More
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className={`text-4xl font-bold bg-gradient-to-r ${gradientFrom} ${gradientTo} bg-clip-text text-transparent mb-4`}>
              Our Professional Process
            </h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto">
              We follow a proven system to ensure exceptional results for every project.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => (
              <div key={index} className="text-center group">
                <div className={`bg-gradient-to-br ${gradientFrom} ${gradientTo} rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                  <span className="text-2xl font-bold text-white">{index + 1}</span>
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">
                  {step.title}
                </h3>
                <p className="text-sm text-gray-600">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20 bg-gradient-to-br from-green-50 via-blue-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className={`text-4xl font-bold bg-gradient-to-r ${gradientFrom} ${gradientTo} bg-clip-text text-transparent mb-4`}>
              Why Choose Arrow Elite Painting?
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="hover:shadow-xl transition-all duration-300 transform hover:scale-105 border-0 shadow-lg">
                <CardContent className="p-6 text-center">
                  <CheckCircle className={`w-12 h-12 text-${accentColor} mx-auto mb-4`} />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{benefit}</h3>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing (if provided) */}
      {pricing && (
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className={`text-4xl font-bold bg-gradient-to-r ${gradientFrom} ${gradientTo} bg-clip-text text-transparent mb-4`}>
                Transparent Pricing
              </h2>
              <p className="text-xl text-gray-600">
                No surprises, just quality work at fair prices.
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              {pricing.map((plan, index) => (
                <Card key={index} className="overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border-0 shadow-lg">
                  <CardHeader className={`bg-gradient-to-br ${gradientFrom} ${gradientTo} text-white text-center`}>
                    <CardTitle className="text-2xl">{plan.title}</CardTitle>
                    <CardDescription className="text-3xl font-bold text-white">
                      {plan.price}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-6">
                    <ul className="space-y-3 mb-6">
                      {plan.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center text-sm">
                          <CheckCircle className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <Button className={`w-full bg-gradient-to-r ${gradientFrom} ${gradientTo} hover:opacity-90 shadow-lg`}>
                      Choose Plan
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Before & After (if provided) */}
      {beforeAfter && (
        <section className="py-20 bg-gradient-to-br from-yellow-50 via-orange-50 to-red-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className={`text-4xl font-bold bg-gradient-to-r ${gradientFrom} ${gradientTo} bg-clip-text text-transparent mb-4`}>
                Before & After Gallery
              </h2>
              <p className="text-xl text-gray-600">
                See the transformation our expert team delivers.
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {beforeAfter.map((project, index) => (
                <Card key={index} className="overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border-0 shadow-lg">
                  <div className="grid grid-cols-2">
                    <div className="relative">
                      <img src={project.before} alt="Before" className="w-full h-40 object-cover" />
                      <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                        <span className="text-white font-bold bg-black/50 px-2 py-1 rounded">BEFORE</span>
                      </div>
                    </div>
                    <div className="relative">
                      <img src={project.after} alt="After" className="w-full h-40 object-cover" />
                      <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                        <span className="text-white font-bold bg-black/50 px-2 py-1 rounded">AFTER</span>
                      </div>
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle className="text-center text-lg">{project.title}</CardTitle>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className={`bg-gradient-to-r ${gradientFrom} ${gradientTo} text-white py-16`}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4 drop-shadow-lg">Ready to Transform Your Space?</h2>
          <p className="text-xl text-white/90 mb-8 drop-shadow">
            Contact us today for a free, no-obligation estimate on your {heroTitle.toLowerCase()} project.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-gray-900 hover:bg-gray-100 shadow-xl transform hover:scale-105 transition-all duration-200">
              <Phone className="w-5 h-5 mr-2" />
              Call (918) 810-3453
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-gray-900 shadow-xl">
              Get Free Estimate Online
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <img 
                  src="/assets/gallery/logo-original.png" 
                  alt="Arrow Elite Painting Logo" 
                  className="h-8 w-auto mr-2"
                  onError={(e) => {
                    e.currentTarget.src = "/assets/logo.png";
                  }}
                />
                <h3 className="text-xl font-bold">Arrow Elite Painting</h3>
              </div>
              <p className="text-gray-300 mb-4">
                Professional painting services for Tulsa's finest homes and businesses.
              </p>
              <div className="space-y-2">
                <div className="flex items-center">
                  <Phone className="w-4 h-4 mr-2" />
                  <a href="tel:9188103453" className="hover:text-orange-400 transition-colors">
                    (918) 810-3453
                  </a>
                </div>
                <p className="text-gray-400 text-sm">arrowelitepainting.com</p>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-gray-300">
                <li><Link to="/interior-painting" className="hover:text-white transition-colors">Interior Painting</Link></li>
                <li><Link to="/exterior-painting" className="hover:text-white transition-colors">Exterior Painting</Link></li>
                <li><Link to="/cabinet-refinishing" className="hover:text-white transition-colors">Cabinet Refinishing</Link></li>
                <li><Link to="/commercial-painting" className="hover:text-white transition-colors">Commercial Painting</Link></li>
                <li><Link to="/color-consultation" className="hover:text-white transition-colors">Color Consultation</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">More Services</h4>
              <ul className="space-y-2 text-gray-300">
                <li><Link to="/residential-painting" className="hover:text-white transition-colors">Residential Painting</Link></li>
                <li><Link to="/deck-staining" className="hover:text-white transition-colors">Deck Staining</Link></li>
                <li><Link to="/pressure-washing" className="hover:text-white transition-colors">Pressure Washing</Link></li>
                <li><a href="#" className="hover:text-white transition-colors">Drywall Repair</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Power Washing</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Service Areas</h4>
              <ul className="space-y-2 text-gray-300">
                <li>Tulsa, OK</li>
                <li>Broken Arrow, OK</li>
                <li>Bixby, OK</li>
                <li>Owasso, OK</li>
                <li>Jenks, OK</li>
                <li>Sand Springs, OK</li>
                <li>Sapulpa, OK</li>
                <li>Glenpool, OK</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-12 pt-8">
            <div className="flex flex-col sm:flex-row justify-between items-center">
              <p className="text-gray-400 text-sm">
                © 2025 Arrow Elite Painting LLC. All rights reserved. | arrowelitepainting.com
              </p>
              <div className="flex space-x-4 mt-4 sm:mt-0">
                <a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">Terms of Use</a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">Warranty</a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}