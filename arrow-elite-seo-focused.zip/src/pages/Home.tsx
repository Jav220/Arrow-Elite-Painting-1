import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* SEO-Optimized Header */}
      <header className="bg-blue-600 text-white py-4">
        <div className="container mx-auto px-4">
          <nav className="flex justify-between items-center">
            <h1 className="text-2xl font-bold">Arrow Elite Painters</h1>
            <div className="space-x-4">
              <Link to="/interior-painting" className="hover:underline">Interior</Link>
              <Link to="/exterior-painting" className="hover:underline">Exterior</Link>
              <Link to="/commercial-painting" className="hover:underline">Commercial</Link>
              <Link to="/contact" className="bg-white text-blue-600 px-4 py-2 rounded hover:bg-gray-100">Get Quote</Link>
            </div>
          </nav>
        </div>
      </header>

      {/* Hero Section - SEO Optimized */}
      <section className="py-20 px-4 text-center bg-gray-50">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-5xl font-bold mb-6 text-gray-900">
            Professional <span className="text-blue-600">Painters in Tulsa</span> & Broken Arrow
          </h2>
          <p className="text-xl text-gray-700 mb-8">
            Licensed painting contractors serving Tulsa, Broken Arrow, Bixby & Jenks. Interior, exterior & commercial painting services with 10+ years experience. FREE estimates!
          </p>
          <div className="space-x-4">
            <Link to="/contact" className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg hover:bg-blue-700">
              Free Estimate
            </Link>
            <a href="tel:9185557246" className="border border-blue-600 text-blue-600 px-8 py-3 rounded-lg text-lg hover:bg-blue-50">
              Call (918) 555-PAINT
            </a>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h3 className="text-3xl font-bold text-center mb-12">Professional Painting Services in Tulsa Oklahoma</h3>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6 border rounded-lg hover:shadow-lg">
              <h4 className="text-xl font-semibold mb-4 text-blue-600">Interior Painting Tulsa</h4>
              <p className="text-gray-600 mb-4">Transform your home with professional interior painting. Bedrooms, living rooms, kitchens & more.</p>
              <Link to="/interior-painting" className="text-blue-600 hover:underline font-medium">Learn More →</Link>
            </div>
            
            <div className="text-center p-6 border rounded-lg hover:shadow-lg">
              <h4 className="text-xl font-semibold mb-4 text-blue-600">Exterior Painting Broken Arrow</h4>
              <p className="text-gray-600 mb-4">Protect & beautify your home's exterior. Weather-resistant paints for Oklahoma climate.</p>
              <Link to="/exterior-painting" className="text-blue-600 hover:underline font-medium">Learn More →</Link>
            </div>
            
            <div className="text-center p-6 border rounded-lg hover:shadow-lg">
              <h4 className="text-xl font-semibold mb-4 text-blue-600">Commercial Painting</h4>
              <p className="text-gray-600 mb-4">Professional commercial painting for offices, retail spaces & warehouses in Tulsa area.</p>
              <Link to="/commercial-painting" className="text-blue-600 hover:underline font-medium">Learn More →</Link>
            </div>
          </div>
        </div>
      </section>

      {/* Local SEO Section */}
      <section className="py-16 bg-gray-50 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <h3 className="text-3xl font-bold mb-8">Trusted Painters Serving Greater Tulsa Area</h3>
          <p className="text-lg text-gray-700 mb-6">
            Arrow Elite Painters proudly serves Tulsa, Broken Arrow, Bixby, Jenks, Owasso and surrounding communities. 
            Licensed, bonded & insured painting contractors with over 10 years of experience.
          </p>
          <div className="grid md:grid-cols-2 gap-8 mt-8">
            <div>
              <h4 className="text-xl font-semibold mb-4">Why Choose Arrow Elite?</h4>
              <ul className="text-left space-y-2 text-gray-700">
                <li>✓ Licensed & Insured Painting Contractors</li>
                <li>✓ 10+ Years Experience in Tulsa Area</li>
                <li>✓ Premium Benjamin Moore & Sherwin Williams Paints</li>
                <li>✓ FREE Detailed Estimates</li>
                <li>✓ 100% Satisfaction Guarantee</li>
              </ul>
            </div>
            <div>
              <h4 className="text-xl font-semibold mb-4">Service Areas</h4>
              <ul className="text-left space-y-2 text-gray-700">
                <li>• Tulsa Interior & Exterior Painting</li>
                <li>• Broken Arrow Residential Painting</li>
                <li>• Bixby House Painters</li>
                <li>• Jenks Commercial Painting</li>
                <li>• Owasso Painting Services</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-600 text-white text-center px-4">
        <div className="container mx-auto max-w-3xl">
          <h3 className="text-3xl font-bold mb-4">Ready for Your Painting Project?</h3>
          <p className="text-xl mb-8">Get your FREE estimate today. Professional painters in Tulsa & Broken Arrow.</p>
          <Link to="/contact" className="bg-white text-blue-600 px-8 py-3 rounded-lg text-lg font-semibold hover:bg-gray-100">
            Get Free Quote Today
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 px-4">
        <div className="container mx-auto text-center">
          <p>&copy; 2024 Arrow Elite Painters | Licensed Painting Contractors Tulsa OK</p>
          <p className="mt-2">Serving Tulsa, Broken Arrow, Bixby, Jenks & Owasso | (918) 555-PAINT</p>
        </div>
      </footer>
    </div>
  );
}