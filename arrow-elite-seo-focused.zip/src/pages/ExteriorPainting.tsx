import { Link } from 'react-router-dom';

export default function ExteriorPainting() {
  return (
    <div className="min-h-screen bg-white">
      <header className="bg-blue-600 text-white py-4">
        <div className="container mx-auto px-4">
          <nav className="flex justify-between items-center">
            <Link to="/" className="text-2xl font-bold">Arrow Elite Painters</Link>
            <div className="space-x-4">
              <Link to="/" className="hover:underline">Home</Link>
              <Link to="/interior-painting" className="hover:underline">Interior</Link>
              <Link to="/commercial-painting" className="hover:underline">Commercial</Link>
              <Link to="/contact" className="bg-white text-blue-600 px-4 py-2 rounded">Contact</Link>
            </div>
          </nav>
        </div>
      </header>

      <section className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto max-w-4xl text-center">
          <h1 className="text-4xl font-bold mb-6">Exterior Painting Services Broken Arrow & Tulsa</h1>
          <p className="text-xl text-gray-700 mb-8">
            Professional exterior house painters protecting homes in Broken Arrow, Tulsa, Bixby & Jenks. 
            Weather-resistant exterior paint, siding painting & complete home makeovers. FREE estimates!
          </p>
          <Link to="/contact" className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg">
            Get Free Exterior Painting Quote
          </Link>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-center mb-12">Exterior House Painting Services Oklahoma</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-2xl font-semibold mb-4 text-blue-600">Complete Exterior Services</h3>
              <ul className="space-y-3 text-gray-700">
                <li>✓ House Siding Painting Broken Arrow</li>
                <li>✓ Trim & Window Painting</li>
                <li>✓ Front Door Painting Services</li>
                <li>✓ Garage Door Painting</li>
                <li>✓ Deck Staining & Painting</li>
                <li>✓ Fence Painting & Staining</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-2xl font-semibold mb-4 text-blue-600">Weather Protection</h3>
              <ul className="space-y-3 text-gray-700">
                <li>✓ Oklahoma Weather-Resistant Paint</li>
                <li>✓ UV Protection Coatings</li>
                <li>✓ Moisture & Mold Resistance</li>
                <li>✓ Pressure Washing & Prep</li>
                <li>✓ Caulking & Sealing</li>
                <li>✓ Long-Lasting Finish Guarantee</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50 px-4">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center mb-8">Exterior Painting Process</h2>
          <div className="grid md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-blue-600 font-bold text-xl">1</span>
              </div>
              <h4 className="font-semibold mb-2">Inspection & Quote</h4>
              <p className="text-gray-600">Free exterior painting estimate in Tulsa area</p>
            </div>
            
            <div>
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-blue-600 font-bold text-xl">2</span>
              </div>
              <h4 className="font-semibold mb-2">Surface Preparation</h4>
              <p className="text-gray-600">Pressure washing, scraping, sanding & priming</p>
            </div>
            
            <div>
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-blue-600 font-bold text-xl">3</span>
              </div>
              <h4 className="font-semibold mb-2">Professional Painting</h4>
              <p className="text-gray-600">Premium exterior paint application</p>
            </div>
            
            <div>
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-blue-600 font-bold text-xl">4</span>
              </div>
              <h4 className="font-semibold mb-2">Final Inspection</h4>
              <p className="text-gray-600">Quality check & customer satisfaction</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-blue-600 text-white text-center px-4">
        <div className="container mx-auto max-w-3xl">
          <h2 className="text-3xl font-bold mb-4">Protect Your Home's Exterior</h2>
          <p className="text-xl mb-8">Professional exterior painting in Broken Arrow & Tulsa. Weather-resistant finishes that last!</p>
          <div className="space-x-4">
            <Link to="/contact" className="bg-white text-blue-600 px-8 py-3 rounded-lg text-lg font-semibold">
              Get Free Estimate
            </Link>
            <a href="tel:9185557246" className="border border-white px-8 py-3 rounded-lg text-lg">
              Call (918) 555-PAINT
            </a>
          </div>
        </div>
      </section>

      <footer className="bg-gray-800 text-white py-8 px-4 text-center">
        <p>&copy; 2024 Arrow Elite Painters | Exterior Painting Contractors Broken Arrow & Tulsa OK</p>
      </footer>
    </div>
  );
}