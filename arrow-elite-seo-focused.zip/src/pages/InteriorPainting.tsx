import { Link } from 'react-router-dom';

export default function InteriorPainting() {
  return (
    <div className="min-h-screen bg-white">
      <header className="bg-blue-600 text-white py-4">
        <div className="container mx-auto px-4">
          <nav className="flex justify-between items-center">
            <Link to="/" className="text-2xl font-bold">Arrow Elite Painters</Link>
            <div className="space-x-4">
              <Link to="/" className="hover:underline">Home</Link>
              <Link to="/exterior-painting" className="hover:underline">Exterior</Link>
              <Link to="/commercial-painting" className="hover:underline">Commercial</Link>
              <Link to="/contact" className="bg-white text-blue-600 px-4 py-2 rounded">Contact</Link>
            </div>
          </nav>
        </div>
      </header>

      {/* SEO Optimized Hero */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto max-w-4xl text-center">
          <h1 className="text-4xl font-bold mb-6">Interior Painting Services Tulsa & Broken Arrow</h1>
          <p className="text-xl text-gray-700 mb-8">
            Professional interior painters transforming homes in Tulsa, Broken Arrow, Bixby & Jenks. 
            Expert room painting, wall preparation & premium finishes. FREE estimates!
          </p>
          <Link to="/contact" className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg">
            Get Free Interior Painting Quote
          </Link>
        </div>
      </section>

      {/* Services */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-center mb-12">Interior Painting Services in Tulsa Oklahoma</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-2xl font-semibold mb-4 text-blue-600">Room Painting Specialists</h3>
              <ul className="space-y-3 text-gray-700">
                <li>✓ Living Room Painting Tulsa</li>
                <li>✓ Bedroom Interior Painting</li>
                <li>✓ Kitchen Cabinet & Wall Painting</li>
                <li>✓ Bathroom Interior Paint Services</li>
                <li>✓ Home Office Painting</li>
                <li>✓ Dining Room Paint Contractors</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-2xl font-semibold mb-4 text-blue-600">Professional Preparation</h3>
              <ul className="space-y-3 text-gray-700">
                <li>✓ Wall Crack Repair & Filling</li>
                <li>✓ Drywall Hole Repair</li>
                <li>✓ Surface Sanding & Smoothing</li>
                <li>✓ Premium Primer Application</li>
                <li>✓ Trim & Baseboard Painting</li>
                <li>✓ Ceiling Painting Services</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-gray-50 px-4">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Our Interior Painters in Tulsa?</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <h4 className="text-xl font-semibold mb-4">Premium Paint Brands</h4>
              <p className="text-gray-700">Benjamin Moore, Sherwin Williams & other top-quality interior paints for lasting results.</p>
            </div>
            
            <div className="text-center">
              <h4 className="text-xl font-semibold mb-4">Expert Color Consultation</h4>
              <p className="text-gray-700">Professional color matching and design advice for your Tulsa area home.</p>
            </div>
            
            <div className="text-center">
              <h4 className="text-xl font-semibold mb-4">Clean & Professional</h4>
              <p className="text-gray-700">Careful preparation, clean worksite, and attention to detail on every project.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-blue-600 text-white text-center px-4">
        <div className="container mx-auto max-w-3xl">
          <h2 className="text-3xl font-bold mb-4">Transform Your Interior Today</h2>
          <p className="text-xl mb-8">Professional interior painting in Tulsa & Broken Arrow. Call for your FREE estimate!</p>
          <div className="space-x-4">
            <Link to="/contact" className="bg-white text-blue-600 px-8 py-3 rounded-lg text-lg font-semibold">
              Get Free Estimate
            </Link>
            <a href="tel:9185557246" className="border border-white px-8 py-3 rounded-lg text-lg">
              Call (918) 555-PAINT
            </a>
          </div>
        </div>
      </section>

      <footer className="bg-gray-800 text-white py-8 px-4 text-center">
        <p>&copy; 2024 Arrow Elite Painters | Interior Painting Contractors Tulsa OK</p>
      </footer>
    </div>
  );
}