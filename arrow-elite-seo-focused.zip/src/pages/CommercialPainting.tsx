import { Link } from 'react-router-dom';

export default function CommercialPainting() {
  return (
    <div className="min-h-screen bg-white">
      <header className="bg-blue-600 text-white py-4">
        <div className="container mx-auto px-4">
          <nav className="flex justify-between items-center">
            <Link to="/" className="text-2xl font-bold">Arrow Elite Painters</Link>
            <div className="space-x-4">
              <Link to="/" className="hover:underline">Home</Link>
              <Link to="/interior-painting" className="hover:underline">Interior</Link>
              <Link to="/exterior-painting" className="hover:underline">Exterior</Link>
              <Link to="/contact" className="bg-white text-blue-600 px-4 py-2 rounded">Contact</Link>
            </div>
          </nav>
        </div>
      </header>

      <section className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto max-w-4xl text-center">
          <h1 className="text-4xl font-bold mb-6">Commercial Painting Contractors Tulsa Oklahoma</h1>
          <p className="text-xl text-gray-700 mb-8">
            Professional commercial painting services in Tulsa, Broken Arrow & surrounding areas. 
            Office buildings, retail spaces, warehouses & more. Licensed commercial painters with flexible scheduling.
          </p>
          <Link to="/contact" className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg">
            Get Commercial Painting Quote
          </Link>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-center mb-12">Commercial Painting Services Tulsa Area</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6 border rounded-lg">
              <h3 className="text-xl font-semibold mb-4 text-blue-600">Office Buildings</h3>
              <ul className="text-left space-y-2 text-gray-700">
                <li>• Corporate Office Painting</li>
                <li>• Reception Area Painting</li>
                <li>• Conference Room Paint</li>
                <li>• Hallway & Common Areas</li>
                <li>• Medical Office Painting</li>
              </ul>
            </div>
            
            <div className="text-center p-6 border rounded-lg">
              <h3 className="text-xl font-semibold mb-4 text-blue-600">Retail Spaces</h3>
              <ul className="text-left space-y-2 text-gray-700">
                <li>• Storefront Painting Tulsa</li>
                <li>• Shopping Center Paint</li>
                <li>• Restaurant Painting</li>
                <li>• Salon & Spa Painting</li>
                <li>• Auto Dealership Paint</li>
              </ul>
            </div>
            
            <div className="text-center p-6 border rounded-lg">
              <h3 className="text-xl font-semibold mb-4 text-blue-600">Industrial & Warehouse</h3>
              <ul className="text-left space-y-2 text-gray-700">
                <li>• Warehouse Floor Coating</li>
                <li>• Industrial Wall Painting</li>
                <li>• Manufacturing Facility</li>
                <li>• Storage Unit Painting</li>
                <li>• Equipment Painting</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-blue-600 text-white text-center px-4">
        <div className="container mx-auto max-w-3xl">
          <h2 className="text-3xl font-bold mb-4">Professional Commercial Painting</h2>
          <p className="text-xl mb-8">Licensed commercial painters in Tulsa with flexible scheduling & minimal business disruption.</p>
          <div className="space-x-4">
            <Link to="/contact" className="bg-white text-blue-600 px-8 py-3 rounded-lg text-lg font-semibold">
              Get Quote Today
            </Link>
            <a href="tel:9185557246" className="border border-white px-8 py-3 rounded-lg text-lg">
              Call (918) 555-PAINT
            </a>
          </div>
        </div>
      </section>

      <footer className="bg-gray-800 text-white py-8 px-4 text-center">
        <p>&copy; 2024 Arrow Elite Painters | Commercial Painting Contractors Tulsa OK</p>
      </footer>
    </div>
  );
}