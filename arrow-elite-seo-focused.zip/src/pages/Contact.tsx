import { useState } from 'react';
import { Link } from 'react-router-dom';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    alert('Thank you! We will contact you within 24 hours for your free estimate.');
  };

  return (
    <div className="min-h-screen bg-white">
      <header className="bg-blue-600 text-white py-4">
        <div className="container mx-auto px-4">
          <nav className="flex justify-between items-center">
            <Link to="/" className="text-2xl font-bold">Arrow Elite Painters</Link>
            <div className="space-x-4">
              <Link to="/" className="hover:underline">Home</Link>
              <Link to="/interior-painting" className="hover:underline">Interior</Link>
              <Link to="/exterior-painting" className="hover:underline">Exterior</Link>
              <Link to="/commercial-painting" className="hover:underline">Commercial</Link>
            </div>
          </nav>
        </div>
      </header>

      <section className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto max-w-4xl text-center">
          <h1 className="text-4xl font-bold mb-6">Get Your FREE Painting Estimate Today</h1>
          <p className="text-xl text-gray-700 mb-8">
            Contact Arrow Elite Painters for professional painting services in Tulsa, Broken Arrow, Bixby & Jenks. 
            Licensed painting contractors with FREE detailed estimates!
          </p>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="grid md:grid-cols-2 gap-12">
            
            {/* Contact Form */}
            <div>
              <h2 className="text-3xl font-bold mb-6">Request Your Free Estimate</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Phone Number *</label>
                  <input
                    type="tel"
                    required
                    placeholder="(918) 555-0123"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Service Needed *</label>
                  <select
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                    value={formData.service}
                    onChange={(e) => setFormData({...formData, service: e.target.value})}
                  >
                    <option value="">Select Service</option>
                    <option value="interior">Interior Painting</option>
                    <option value="exterior">Exterior Painting</option>
                    <option value="commercial">Commercial Painting</option>
                    <option value="both">Interior & Exterior</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">Project Details</label>
                  <textarea
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                    placeholder="Tell us about your painting project..."
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                  />
                </div>
                
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg text-lg font-semibold hover:bg-blue-700"
                >
                  Get FREE Estimate
                </button>
              </form>
            </div>

            {/* Contact Info */}
            <div>
              <h2 className="text-3xl font-bold mb-6">Contact Arrow Elite Painters</h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold mb-2 text-blue-600">Phone</h3>
                  <p className="text-lg">(918) 555-PAINT</p>
                  <p className="text-gray-600">Call for immediate assistance</p>
                </div>
                
                <div>
                  <h3 className="text-xl font-semibold mb-2 text-blue-600">Service Areas</h3>
                  <ul className="space-y-1 text-gray-700">
                    <li>• Tulsa Interior & Exterior Painting</li>
                    <li>• Broken Arrow Residential Painters</li>
                    <li>• Bixby House Painting Services</li>
                    <li>• Jenks Commercial Painting</li>
                    <li>• Owasso & Surrounding Areas</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-xl font-semibold mb-2 text-blue-600">Business Hours</h3>
                  <div className="text-gray-700">
                    <p>Monday - Friday: 7:00 AM - 7:00 PM</p>
                    <p>Saturday: 8:00 AM - 6:00 PM</p>
                    <p>Sunday: Emergency Service Only</p>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-xl font-semibold mb-2 text-blue-600">Licensed & Insured</h3>
                  <p className="text-gray-700">Fully licensed painting contractors in Oklahoma. Bonded and insured for your protection.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-blue-600 text-white text-center px-4">
        <div className="container mx-auto max-w-3xl">
          <h2 className="text-3xl font-bold mb-4">Ready to Start Your Painting Project?</h2>
          <p className="text-xl mb-8">Call Arrow Elite Painters today for your FREE estimate in Tulsa & Broken Arrow!</p>
          <a href="tel:9185557246" className="bg-white text-blue-600 px-8 py-3 rounded-lg text-xl font-semibold hover:bg-gray-100">
            Call (918) 555-PAINT Now
          </a>
        </div>
      </section>

      <footer className="bg-gray-800 text-white py-8 px-4 text-center">
        <p>&copy; 2024 Arrow Elite Painters | Licensed Painting Contractors Tulsa & Broken Arrow OK</p>
      </footer>
    </div>
  );
}